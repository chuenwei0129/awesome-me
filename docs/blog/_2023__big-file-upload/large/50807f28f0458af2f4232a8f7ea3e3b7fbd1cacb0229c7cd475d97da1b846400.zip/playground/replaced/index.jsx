import Card from './Card'

export default function ReplacedElement() {
  return (
    <div>
      <Card objectFit="fill"></Card>
      <br />
      <Card objectFit="cover"></Card>
      <br />
      <Card objectFit="contain"></Card>
      <br />
      <Card objectFit="none"></Card>
      <br />
      <Card objectFit="scale-down"></Card>
    </div>
  )
}
