import classNames from 'classnames'

export default function Card({ objectFit }) {
  const imgClass = classNames(
    'block min-w-[100%] aspect-video', // 基础的 Tailwind 类
    {
      'object-fill': objectFit === 'fill',
      'object-cover': objectFit === 'cover',
      'object-contain': objectFit === 'contain',
      'object-none': objectFit === 'none',
      'object-scale-down': objectFit === 'scale-down',
    },
  )
  return (
    <figure className="max-w-[200px] flex rounded-[10px] bg-[#f5f5f5] has-[figcaption]:flex-col has-[figcaption]:gap-4 has-[figcaption]:p-[10px]">
      {/* 这里 img 元素的宽度为 200px，高度自适应 */}
      {/*  图片尺寸 100x100 16:9 */}
      <img
        className={imgClass}
        src="https://placebear.com/g/100/100"
        alt="logo"
      />
      <figcaption className={"text-[rgb(172,144,102)] hover:text-blue-300'"}>
        <span>object-fit: {objectFit}</span>
      </figcaption>
    </figure>
  )
}
