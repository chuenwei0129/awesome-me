import postcss from 'postcss'

const ast = postcss.parse(`* {
  margin: 0;
  padding: 0;
}

body {
  background-color: #fff;
}

#app {
  width: 100%;
  height: 100vh;
}`)

console.log(JSON.stringify(ast))
