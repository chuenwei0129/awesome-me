---
# 自定义二级导航
nav:
  second:
    title: JavaScript
    order: 0
# 菜单栏标题
# title: 介绍
order: -999
# 菜单栏分组
group:
  title: 介绍
  order: -999
---

# 这是什么？

> 一个充满了既神奇又无用的 JavaScript 知识的合集。
>
> 为什么要研究这些？因为它就在那儿呀！

<img src="https://raw.githubusercontent.com/chuenwei0129/my-picgo-repo/master/me/F2Gacz4WkAAQZuh.jpeg" width="40%" alt="javascript"/>
