---
title: Fetch
order: -1
toc: content
group:
  title: 浏览器工作原理
---

[为什么当今 Web 应用不都采用 WebSocket 形式进行数据交互？](https://www.zhihu.com/question/417163973)

