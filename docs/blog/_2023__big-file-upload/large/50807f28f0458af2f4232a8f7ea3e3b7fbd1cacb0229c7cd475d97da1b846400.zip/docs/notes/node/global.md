---
title: global 全局对象
order: 3
toc: content
group:
  title: 基础知识
---

![20240423131946](https://raw.githubusercontent.com/chuenwei0129/my-picgo-repo/master/me/20240423131946.png)

![20240423133217](https://raw.githubusercontent.com/chuenwei0129/my-picgo-repo/master/me/20240423133217.png)

![20240423140534](https://raw.githubusercontent.com/chuenwei0129/my-picgo-repo/master/me/20240423140534.png)

![20240423141105](https://raw.githubusercontent.com/chuenwei0129/my-picgo-repo/master/me/20240423141105.png)

![20240423141444](https://raw.githubusercontent.com/chuenwei0129/my-picgo-repo/master/me/20240423141444.png)
