---
title: 什么是命令？
order: 0
toc: content
group:
  title: shell
---

## 什么是命令？

## 如何识别命令

## 常用命令

## I/O 重定向

## 展开（expansion）和引用（quoting）
