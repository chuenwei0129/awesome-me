---
nav:
  title: 组件库
  order: 0
title: Foo 组件
group:
  title: Pro 组件
  order: -1
---

# Foo

This is an example component.

```jsx
import { Foo } from 'awesome-me'

export default () => <Foo title="Hello dumi!" />
```
