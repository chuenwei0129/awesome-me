---
nav:
  title: 组件
  path: /components
---

## Foo

Demo:

```tsx
import React from 'react'
// import { Foo } from 'dumi-template';

// export default () => <Foo title="First Demo" />;
```

[更多技巧](https://d.umijs.org/guide/demo-principle)
