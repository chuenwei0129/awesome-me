import React, { type FC } from 'react'
import styled from 'styled-components'

const Button = styled.button`
  color: #fff;
  background-color: #007bff;
  border-color: #007bff;
  display: inline-block;
  font-weight: 400;
  text-align: center;
`

const Bar: FC<{ title: string }> = (props) => (
  <>
    <h4>{props.title}</h4>
    <Button className="text-blue-200">hello world</Button>
    <div className="text-blue-200">hello world</div>
  </>
)

export default Bar
