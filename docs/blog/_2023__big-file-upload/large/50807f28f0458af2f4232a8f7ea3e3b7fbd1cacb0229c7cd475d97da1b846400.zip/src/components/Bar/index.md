---
title: Bar 组件
group:
  title: 原子组件
  order: 0
---

# Bar

This is an example component.

```jsx
import { Bar } from 'awesome-me'

export default () => <Bar title="Hello Bar" />
```
